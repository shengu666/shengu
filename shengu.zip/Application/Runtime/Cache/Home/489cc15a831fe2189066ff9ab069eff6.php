<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html><html><head><meta charset=utf-8><title>manage-system</title><meta name=viewport content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"><meta name=keywords content="vue.js, wms, vue2, 后台模板, 管理系统, element"><meta name=description content="基于Vue2 + Element UI 的后台管理系统解决方案"><link href=./static/css/app.260fd38757c8d00ad9ef739ca97bb2c9.css rel=stylesheet></head><body><div id=app></div><script>var _hmt = _hmt || [];
    (function() {
        var hm = document.createElement("script");
        hm.src = "https://hm.baidu.com/hm.js?1ad0a5c62a113bb874be8bb514b0a70d";
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(hm, s);
    })();</script><script type=text/javascript src=./static/js/manifest.87847c6afd3495eb5cd5.js></script><script type=text/javascript src=./static/js/vendor.2de1ff6d90aee2253c48.js></script><script type=text/javascript src=./static/js/app.d75d6e54e9cf0c2d7c7f.js></script></body></html>